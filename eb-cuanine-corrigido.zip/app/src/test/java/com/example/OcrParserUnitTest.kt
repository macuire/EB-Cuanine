package com.example

import com.example.data.model.Student
import com.example.util.OcrLine
import com.example.util.OcrScannerHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OcrParserUnitTest {

    private fun student(id: Long, name: String, number: String) = Student(
        id = id,
        studentNumber = number,
        fullName = name,
        birthDate = "2015-01-01",
        gender = "M",
        guardianName = "Encarregado",
        guardianPhone = "+258 84 000 0000",
        cycle = 2,
        gradeClass = 4
    )

    @Test
    fun extraiNotasDepoisDoNomeEIgnoraONumeroDoAluno() {
        val grades = OcrScannerHelper.extractGrades("1 Julio Ernesto Cossa EBC-2026-101 12,5 14 13 15", "EBC-2026-101")
        assertEquals(listOf(12.5, 14.0, 13.0, 15.0), grades)
    }

    @Test
    fun ignoraValoresForaDoIntervaloDe0a20() {
        val grades = OcrScannerHelper.extractGrades("Marta David Matsinhe 35 12 99", "")
        assertEquals(listOf(12.0), grades)
    }

    @Test
    fun associaLinhasPorProximidadeVertical() {
        val lines = listOf(
            OcrLine("Julio Ernesto Cossa", left = 10, top = 100, bottom = 120),
            OcrLine("12", left = 300, top = 102, bottom = 122),
            OcrLine("14", left = 360, top = 101, bottom = 121),
            OcrLine("Marta David Matsinhe", left = 10, top = 160, bottom = 180),
            OcrLine("16", left = 300, top = 161, bottom = 181)
        )
        val students = listOf(
            student(1, "Julio Ernesto Cossa", "EBC-2026-101"),
            student(2, "Marta David Matsinhe", "EBC-2026-102")
        )
        val rows = OcrScannerHelper.buildRows(lines, students)
        assertEquals(2, rows.size)
        assertEquals(12.0, rows[0].acs1!!, 0.001)
        assertEquals(14.0, rows[0].acs2!!, 0.001)
        assertEquals(16.0, rows[1].acs1!!, 0.001)
    }

    @Test
    fun alunoNaoEncontradoFicaSemNotas() {
        val lines = listOf(OcrLine("Julio Ernesto Cossa 12 14", left = 10, top = 100, bottom = 120))
        val students = listOf(
            student(1, "Julio Ernesto Cossa", "EBC-2026-101"),
            student(2, "Nelson Zacarias Tembe", "EBC-2026-103")
        )
        val rows = OcrScannerHelper.buildRows(lines, students)
        assertNull(rows[1].acs1)
        assertTrue(rows[1].notes.contains("não encontrado"))
    }

    @Test
    fun semTextoNaoInventaNotas() {
        val rows = OcrScannerHelper.buildRows(emptyList(), listOf(student(1, "Julio Ernesto Cossa", "EBC-2026-101")))
        assertNull(rows[0].acs1)
        assertNull(rows[0].exam)
    }
}
