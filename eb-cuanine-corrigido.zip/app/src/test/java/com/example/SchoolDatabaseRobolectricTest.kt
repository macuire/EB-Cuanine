package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.dao.SchoolDao
import com.example.data.database.AppDatabase
import com.example.data.model.AttendanceRecord
import com.example.data.model.GradeRecord
import com.example.data.model.PautaLock
import com.example.data.model.Student
import com.example.data.model.Teacher
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SchoolDatabaseRobolectricTest {

    private lateinit var db: AppDatabase
    private lateinit var dao: SchoolDao

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        dao = db.schoolDao()
    }

    @After
    fun closeDb() {
        db.close()
    }

    @Test
    fun testInsertAndRetrieveStudent() = runBlocking {
        val student = Student(
            studentNumber = "EBC-2026-999",
            fullName = "Aníbal Muchanga",
            birthDate = "2013-05-12",
            gender = "M",
            guardianName = "Fátima Muchanga",
            guardianPhone = "+258 84 999 1122",
            address = "Bairro Cuanine 1",
            cycle = 2,
            gradeClass = 4,
            section = "A",
            docType = "BI",
            docNumber = "110100998811A",
            enrollmentStatus = "ACTIVO"
        )
        val id = dao.insertStudent(student)
        assertTrue(id > 0)

        val retrieved = dao.getStudentByIdDirect(id)
        assertNotNull(retrieved)
        assertEquals("Aníbal Muchanga", retrieved?.fullName)
        assertEquals("EBC-2026-999", retrieved?.studentNumber)
        assertEquals(4, retrieved?.gradeClass)
        assertEquals("ACTIVO", retrieved?.enrollmentStatus)
    }

    @Test
    fun testTeacherCrud() = runBlocking {
        val teacher = Teacher(
            teacherCode = "DOC-EBC-99",
            fullName = "Prof. Mateus Tembe",
            gender = "M",
            contractType = "Contratado",
            category = "Docente N2",
            assignedClassroom = "Sala 4 - Bloco B",
            mainSubjects = "Geografia, História",
            phone = "+258 84 111 2233"
        )
        val id = dao.insertTeacher(teacher)
        assertTrue(id > 0)

        val count = dao.countTeachers()
        assertEquals(1, count)

        val teachers = dao.getAllTeachers().first()
        assertEquals(1, teachers.size)
        assertEquals("Prof. Mateus Tembe", teachers[0].fullName)
    }

    @Test
    fun testAttendanceRecording() = runBlocking {
        val attendance1 = AttendanceRecord(
            studentId = 101L,
            subjectId = 1L,
            date = "2026-03-01",
            status = "P",
            term = 1
        )
        val attendance2 = AttendanceRecord(
            studentId = 102L,
            subjectId = 1L,
            date = "2026-03-01",
            status = "FJ",
            term = 1
        )
        dao.insertAttendances(listOf(attendance1, attendance2))

        val records = dao.getAttendanceForClassAndDate(listOf(101L, 102L), 1L, "2026-03-01").first()
        assertEquals(2, records.size)
        assertEquals("P", records.find { it.studentId == 101L }?.status)
        assertEquals("FJ", records.find { it.studentId == 102L }?.status)
    }

    @Test
    fun testPautaLockAndGovernance() = runBlocking {
        val lock = PautaLock(
            gradeClass = 10,
            section = "A",
            subjectId = 1L,
            term = 1,
            isLocked = true,
            lockedBy = "Conselho de Notas 1.º Trimestre",
            unlockReason = null
        )
        dao.insertOrUpdateLock(lock)

        val directLock = dao.getPautaLockDirect(10, "A", 1L, 1)
        assertNotNull(directLock)
        assertTrue(directLock?.isLocked == true)

        // Técnico ICT desbloqueia
        val unlocked = lock.copy(isLocked = false, unlockReason = "Revisão autorizada pelo Director")
        dao.insertOrUpdateLock(unlocked)

        val updatedLock = dao.getPautaLockDirect(10, "A", 1L, 1)
        assertEquals(false, updatedLock?.isLocked)
        assertEquals("Revisão autorizada pelo Director", updatedLock?.unlockReason)
    }

    @Test
    fun testStudentEnrollmentStatusTransitions() = runBlocking {
        val student = Student(
            studentNumber = "EBC-2026-555",
            fullName = "Carla Sitoe",
            birthDate = "2012-08-20",
            gender = "F",
            guardianName = "Ernesto Sitoe",
            guardianPhone = "+258 82 444 3322",
            address = "Manhiça Sede",
            cycle = 3,
            gradeClass = 7,
            section = "B",
            enrollmentStatus = "ACTIVO"
        )
        val id = dao.insertStudent(student)

        // Actualizar para TRANSFERIDO
        dao.updateEnrollmentStatus(id, "TRANSFERIDO", "EPC Manhiça Vila", "Mudança de residência da família")
        val updated = dao.getStudentByIdDirect(id)
        assertEquals("TRANSFERIDO", updated?.enrollmentStatus)
        assertEquals("EPC Manhiça Vila", updated?.transferDestination)
        assertEquals("Mudança de residência da família", updated?.dropReason)
    }
}
