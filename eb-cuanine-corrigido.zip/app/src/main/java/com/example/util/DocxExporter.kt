package com.example.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.example.data.model.Classroom
import com.example.data.model.GradeRecord
import com.example.data.model.Student
import com.example.data.model.Subject
import java.io.File
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object DocxExporter {

    private fun getExportDir(context: Context): File {
        val dir = File(context.filesDir, "exports")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun shareDocx(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "Abrir / Partilhar no Word / WPS: ${file.name}")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    private fun escapeXml(str: String): String {
        return str
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }

    private fun createDocxArchive(outFile: File, documentXmlContent: String) {
        val contentTypesXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>"""

        val rootRelsXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

        val docRelsXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

        val stylesXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:docDefaults>
    <w:rPrDefault>
      <w:rPr>
        <w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/>
        <w:sz w:val="22"/>
      </w:rPr>
    </w:rPrDefault>
  </w:docDefaults>
</w:styles>"""

        ZipOutputStream(FileOutputStream(outFile)).use { zos ->
            fun put(name: String, content: String) {
                val entry = ZipEntry(name)
                zos.putNextEntry(entry)
                zos.write(content.toByteArray(StandardCharsets.UTF_8))
                zos.closeEntry()
            }

            put("[Content_Types].xml", contentTypesXml)
            put("_rels/.rels", rootRelsXml)
            put("word/_rels/document.xml.rels", docRelsXml)
            put("word/styles.xml", stylesXml)
            put("word/document.xml", documentXmlContent)
        }
    }

    /**
     * Exporta a Pauta da Turma em formato Word (.docx) 100% editável no Word e WPS Office.
     */
    fun exportPautaDocx(
        context: Context,
        classroom: Classroom,
        subject: Subject,
        term: Int,
        students: List<Student>,
        gradesMap: Map<Long, GradeRecord>
    ): File {
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val dateStr = sdf.format(Date())

        val rowsXml = StringBuilder()

        // Cabeçalho da tabela
        rowsXml.append("""
            <w:tr>
              <w:trPr><w:tblHeader/></w:trPr>
              <w:tc><w:tcPr><w:shd w:fill="0A2540"/><w:tcW w:w="600" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>N.º</w:t></w:r></w:p></w:tc>
              <w:tc><w:tcPr><w:shd w:fill="0A2540"/><w:tcW w:w="3800" w:type="dxa"/></w:tcPr><w:p><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>Nome Completo do Aluno</w:t></w:r></w:p></w:tc>
              <w:tc><w:tcPr><w:shd w:fill="0A2540"/><w:tcW w:w="900" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>ACS 1</w:t></w:r></w:p></w:tc>
              <w:tc><w:tcPr><w:shd w:fill="0A2540"/><w:tcW w:w="900" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>ACS 2</w:t></w:r></w:p></w:tc>
              <w:tc><w:tcPr><w:shd w:fill="0A2540"/><w:tcW w:w="900" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>AT</w:t></w:r></w:p></w:tc>
              <w:tc><w:tcPr><w:shd w:fill="0A2540"/><w:tcW w:w="1100" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>MÉDIA</w:t></w:r></w:p></w:tc>
              <w:tc><w:tcPr><w:shd w:fill="0A2540"/><w:tcW w:w="1400" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>RESULTADO</w:t></w:r></w:p></w:tc>
            </w:tr>
        """.trimIndent())

        students.forEachIndexed { index, student ->
            val grade = gradesMap[student.id]
            val bgFill = if (index % 2 == 1) "F8FAFC" else "FFFFFF"

            val acs1Str = grade?.acs1?.let { String.format(Locale.US, "%.1f", it) } ?: "-"
            val acs2Str = grade?.acs2?.let { String.format(Locale.US, "%.1f", it) } ?: "-"
            val atStr = grade?.at?.let { String.format(Locale.US, "%.1f", it) } ?: "-"
            val avg = grade?.termAverage
            val avgStr = avg?.let { String.format(Locale.US, "%.1f", it) } ?: "-"
            val isPass = avg != null && avg >= 10.0
            val resStr = if (avg == null) "Pendente" else if (isPass) "Aprovado" else "Reprovado"
            val resColor = if (isPass) "16A34A" else "DC2626"

            rowsXml.append("""
                <w:tr>
                  <w:tc><w:tcPr><w:shd w:fill="$bgFill"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>${index + 1}</w:t></w:r></w:p></w:tc>
                  <w:tc><w:tcPr><w:shd w:fill="$bgFill"/></w:tcPr><w:p><w:r><w:t>${escapeXml(student.fullName)}</w:t></w:r></w:p></w:tc>
                  <w:tc><w:tcPr><w:shd w:fill="$bgFill"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>$acs1Str</w:t></w:r></w:p></w:tc>
                  <w:tc><w:tcPr><w:shd w:fill="$bgFill"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>$acs2Str</w:t></w:r></w:p></w:tc>
                  <w:tc><w:tcPr><w:shd w:fill="$bgFill"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>$atStr</w:t></w:r></w:p></w:tc>
                  <w:tc><w:tcPr><w:shd w:fill="$bgFill"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>$avgStr</w:t></w:r></w:p></w:tc>
                  <w:tc><w:tcPr><w:shd w:fill="$bgFill"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="$resColor"/></w:rPr><w:t>$resStr</w:t></w:r></w:p></w:tc>
                </w:tr>
            """.trimIndent())
        }

        val docXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    <w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="26"/></w:rPr><w:t>REPÚBLICA DE MOÇAMBIQUE</w:t></w:r></w:p>
    <w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:sz w:val="20"/><w:color w:val="475569"/></w:rPr><w:t>MINISTÉRIO DA EDUCAÇÃO E DESENVOLVIMENTO HUMANO</w:t></w:r></w:p>
    <w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:sz w:val="20"/><w:color w:val="475569"/></w:rPr><w:t>GOVERNO DO DISTRITO DA MANHIÇA - ESCOLA BÁSICA DE CUANINE</w:t></w:r></w:p>
    <w:p/>
    <w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="24"/><w:color w:val="0A2540"/></w:rPr><w:t>PAUTA OFICIAL DE AVALIAÇÃO - $term.º TRIMESTRE / 2026</w:t></w:r></w:p>
    <w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Turma: </w:t></w:r><w:r><w:t>${classroom.grade}.ª Classe '${classroom.section}'  |  Ciclo: ${SneCalculator.getCycleTitle(classroom.cycle)}  |  Turno: ${classroom.shift}</w:t></w:r></w:p>
    <w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Disciplina: </w:t></w:r><w:r><w:t>${escapeXml(subject.name)}  |  Professor(a): ${escapeXml(classroom.classTeacher)}</w:t></w:r></w:p>
    <w:p/>
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="0" w:type="auto"/>
        <w:tblBorders>
          <w:top w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/>
          <w:left w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/>
          <w:bottom w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/>
          <w:right w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/>
          <w:insideH w:val="single" w:sz="4" w:space="0" w:color="E2E8F0"/>
          <w:insideV w:val="single" w:sz="4" w:space="0" w:color="E2E8F0"/>
        </w:tblBorders>
      </w:tblPr>
      $rowsXml
    </w:tbl>
    <w:p/>
    <w:p><w:r><w:rPr><w:i/><w:sz w:val="18"/><w:color w:val="64748B"/></w:rPr><w:t>Emitido em Cuanine, Manhiça aos $dateStr</w:t></w:r></w:p>
    <w:p/>
    <w:p/>
    <w:p><w:r><w:t>_____________________________________                 _____________________________________</w:t></w:r></w:p>
    <w:p><w:r><w:rPr><w:b/></w:rPr><w:t>     O Professor da Disciplina                                      A Direcção da Escola</w:t></w:r></w:p>
  </w:body>
</w:document>"""

        val filename = "Pauta_${classroom.grade}Class_${classroom.section}_${subject.code}_T$term.docx"
        val outFile = File(getExportDir(context), filename)
        createDocxArchive(outFile, docXml)
        return outFile
    }

    /**
     * Exporta Boletim Individual do Aluno em Word (.docx) editável.
     */
    fun exportBoletimDocx(
        context: Context,
        student: Student,
        subjects: List<Subject>,
        grades: List<GradeRecord>
    ): File {
        val rowsXml = StringBuilder()

        rowsXml.append("""
            <w:tr>
              <w:trPr><w:tblHeader/></w:trPr>
              <w:tc><w:tcPr><w:shd w:fill="0A2540"/><w:tcW w:w="4000" w:type="dxa"/></w:tcPr><w:p><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>Disciplina</w:t></w:r></w:p></w:tc>
              <w:tc><w:tcPr><w:shd w:fill="0A2540"/><w:tcW w:w="1200" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>1.º Trim</w:t></w:r></w:p></w:tc>
              <w:tc><w:tcPr><w:shd w:fill="0A2540"/><w:tcW w:w="1200" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>2.º Trim</w:t></w:r></w:p></w:tc>
              <w:tc><w:tcPr><w:shd w:fill="0A2540"/><w:tcW w:w="1200" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>3.º Trim</w:t></w:r></w:p></w:tc>
              <w:tc><w:tcPr><w:shd w:fill="0A2540"/><w:tcW w:w="1400" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>Média Final</w:t></w:r></w:p></w:tc>
              <w:tc><w:tcPr><w:shd w:fill="0A2540"/><w:tcW w:w="1600" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>Resultado</w:t></w:r></w:p></w:tc>
            </w:tr>
        """.trimIndent())

        subjects.forEachIndexed { idx, sub ->
            val bg = if (idx % 2 == 1) "F8FAFC" else "FFFFFF"
            val g1 = grades.find { it.subjectId == sub.id && it.term == 1 }
            val g2 = grades.find { it.subjectId == sub.id && it.term == 2 }
            val g3 = grades.find { it.subjectId == sub.id && it.term == 3 }

            val s1 = g1?.termAverage?.let { String.format(Locale.US, "%.1f", it) } ?: "-"
            val s2 = g2?.termAverage?.let { String.format(Locale.US, "%.1f", it) } ?: "-"
            val s3 = g3?.termAverage?.let { String.format(Locale.US, "%.1f", it) } ?: "-"

            val valid = listOfNotNull(g1?.termAverage, g2?.termAverage, g3?.termAverage)
            val avgStr: String
            val resStr: String
            val resColor: String
            if (valid.isNotEmpty()) {
                val a = valid.average()
                avgStr = String.format(Locale.US, "%.1f", a)
                val pass = a >= 10.0
                resStr = if (pass) "Aprovado" else "Reprovado"
                resColor = if (pass) "16A34A" else "DC2626"
            } else {
                avgStr = "-"
                resStr = "Pendente"
                resColor = "64748B"
            }

            rowsXml.append("""
                <w:tr>
                  <w:tc><w:tcPr><w:shd w:fill="$bg"/></w:tcPr><w:p><w:r><w:t>${escapeXml(sub.name)}</w:t></w:r></w:p></w:tc>
                  <w:tc><w:tcPr><w:shd w:fill="$bg"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>$s1</w:t></w:r></w:p></w:tc>
                  <w:tc><w:tcPr><w:shd w:fill="$bg"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>$s2</w:t></w:r></w:p></w:tc>
                  <w:tc><w:tcPr><w:shd w:fill="$bg"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:t>$s3</w:t></w:r></w:p></w:tc>
                  <w:tc><w:tcPr><w:shd w:fill="$bg"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>$avgStr</w:t></w:r></w:p></w:tc>
                  <w:tc><w:tcPr><w:shd w:fill="$bg"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="$resColor"/></w:rPr><w:t>$resStr</w:t></w:r></w:p></w:tc>
                </w:tr>
            """.trimIndent())
        }

        val docXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    <w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="26"/></w:rPr><w:t>REPÚBLICA DE MOÇAMBIQUE</w:t></w:r></w:p>
    <w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:sz w:val="20"/><w:color w:val="475569"/></w:rPr><w:t>MINISTÉRIO DA EDUCAÇÃO E DESENVOLVIMENTO HUMANO</w:t></w:r></w:p>
    <w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:sz w:val="20"/><w:color w:val="475569"/></w:rPr><w:t>ESCOLA BÁSICA DE CUANINE - DISTRITO DA MANHIÇA</w:t></w:r></w:p>
    <w:p/>
    <w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="24"/><w:color w:val="0A2540"/></w:rPr><w:t>BOLETIM INDIVIDUAL DE APROVEITAMENTO ESCOLAR</w:t></w:r></w:p>
    <w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Nome do Aluno: </w:t></w:r><w:r><w:t>${escapeXml(student.fullName)}</w:t></w:r></w:p>
    <w:p><w:r><w:rPr><w:b/></w:rPr><w:t>N.º de Matrícula: </w:t></w:r><w:r><w:t>${student.studentNumber}</w:t></w:r><w:r><w:rPr><w:b/></w:rPr><w:t>  |  Classe: </w:t></w:r><w:r><w:t>${student.gradeClass}.ª Classe '${student.section}'</w:t></w:r></w:p>
    <w:p><w:r><w:rPr><w:b/></w:rPr><w:t>Encarregado de Educação: </w:t></w:r><w:r><w:t>${escapeXml(student.guardianName)} (${student.guardianPhone})</w:t></w:r></w:p>
    <w:p/>
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="0" w:type="auto"/>
        <w:tblBorders>
          <w:top w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/>
          <w:left w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/>
          <w:bottom w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/>
          <w:right w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/>
          <w:insideH w:val="single" w:sz="4" w:space="0" w:color="E2E8F0"/>
          <w:insideV w:val="single" w:sz="4" w:space="0" w:color="E2E8F0"/>
        </w:tblBorders>
      </w:tblPr>
      $rowsXml
    </w:tbl>
  </w:body>
</w:document>"""

        val clean = student.fullName.replace(" ", "_").take(15)
        val outFile = File(getExportDir(context), "Boletim_${student.studentNumber}_$clean.docx")
        createDocxArchive(outFile, docXml)
        return outFile
    }
}
