package com.example.util

import com.example.data.model.FormulaConfig
import com.example.data.model.GradeRecord

object SneCalculator {

    /**
     * Calcula a Média Trimestral (MT) de acordo com o Ciclo e pesos configurados no SNE.
     */
    fun calculateTermAverage(
        cycle: Int,
        acs1: Double?,
        acs2: Double?,
        at: Double?,
        config: FormulaConfig? = null
    ): Double? {
        val pAcs1 = config?.acs1Weight ?: 1.0
        val pAcs2 = config?.acs2Weight ?: 1.0
        val pAt = config?.atWeight ?: 2.0

        var totalWeight = 0.0
        var totalPoints = 0.0

        if (acs1 != null) {
            totalPoints += acs1 * pAcs1
            totalWeight += pAcs1
        }
        if (acs2 != null) {
            totalPoints += acs2 * pAcs2
            totalWeight += pAcs2
        }
        if (at != null) {
            totalPoints += at * pAt
            totalWeight += pAt
        }

        if (totalWeight == 0.0) return null

        val rawAvg = totalPoints / totalWeight
        return Math.round(rawAvg * 10.0) / 10.0 // Arredondamento a 1 casa decimal
    }

    /**
     * Converte nota numérica (0-20) em menção qualitativa do 1.º Ciclo do SNE.
     */
    fun getQualitativeMention(grade: Double?): String {
        if (grade == null) return "Sem Avaliação"
        return when {
            grade >= 16.0 -> "Muito Bom"
            grade >= 13.5 -> "Bom"
            grade >= 10.0 -> "Suficiente"
            else -> "Não Suficiente"
        }
    }

    /**
     * Sigla curta para pautas do 1.º Ciclo (MB, B, S, NS).
     */
    fun getQualitativeShort(grade: Double?): String {
        if (grade == null) return "-"
        return when {
            grade >= 16.0 -> "MB"
            grade >= 13.5 -> "B"
            grade >= 10.0 -> "S"
            else -> "NS"
        }
    }

    /**
     * Determina se o aluno está aprovado ou reprovado no SNE.
     */
    fun isPassing(grade: Double?, cycle: Int, minPass: Double = 10.0): Boolean {
        if (grade == null) return false
        return grade >= minPass
    }

    /**
     * Determina o ciclo (1, 2 ou 3) a partir da classe (1 à 10).
     */
    fun getCycleForGrade(gradeClass: Int): Int {
        return when (gradeClass) {
            1, 2 -> 1
            3, 4, 5 -> 2
            else -> 3
        }
    }

    /**
     * Descrição do Ciclo.
     */
    fun getCycleTitle(cycle: Int): String {
        return when (cycle) {
            1 -> "1.º Ciclo (1.ª e 2.ª Classes)"
            2 -> "2.º Ciclo (3.ª à 5.ª Classes)"
            3 -> "3.º Ciclo (6.ª à 10.ª Classes)"
            else -> "$cycle.º Ciclo"
        }
    }
}
