package com.example.util

import android.content.Context
import android.net.Uri
import com.example.data.model.Student
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.text.Normalizer
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

data class ScannedGradeRow(
    val id: Long = System.currentTimeMillis() + (0..999).random(),
    var studentName: String,
    var studentNumber: String,
    var matchedStudentId: Long? = null,
    var acs1: Double? = null,
    var acs2: Double? = null,
    var at: Double? = null,
    var exam: Double? = null,
    var notes: String = ""
)

/** Uma linha de texto reconhecida pelo OCR, com a sua posição na imagem. */
data class OcrLine(
    val text: String,
    val left: Int,
    val top: Int,
    val bottom: Int
)

/**
 * Leitura de pautas físicas com Google ML Kit (reconhecimento de texto no dispositivo, offline).
 *
 * O OCR NUNCA grava notas: devolve apenas uma proposta que o utilizador deve rever e corrigir
 * no diálogo de validação antes de confirmar.
 */
object OcrScannerHelper {

    private const val NOT_FOUND_NOTE = "Aluno não encontrado na imagem — preencha manualmente."
    private const val FOUND_NOTE = "Lido por OCR — confirme cada valor com a pauta em papel."

    /** Lê a imagem e devolve uma linha por aluno activo da turma. Lança excepção se a imagem não puder ser lida. */
    suspend fun processPaperGradeSheet(
        context: Context,
        imageUri: Uri,
        knownStudents: List<Student>
    ): List<ScannedGradeRow> {
        if (knownStudents.isEmpty()) return emptyList()
        val lines = recognizeLines(context, imageUri)
        return buildRows(lines, knownStudents)
    }

    private suspend fun recognizeLines(context: Context, imageUri: Uri): List<OcrLine> =
        withContext(Dispatchers.IO) {
            val image = InputImage.fromFilePath(context, imageUri)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            try {
                val result = suspendCancellableCoroutine { cont ->
                    recognizer.process(image)
                        .addOnSuccessListener { cont.resume(it) }
                        .addOnFailureListener { cont.resumeWithException(it) }
                }
                val out = mutableListOf<OcrLine>()
                for (block in result.textBlocks) {
                    for (line in block.lines) {
                        val box = line.boundingBox ?: continue
                        out.add(OcrLine(line.text, box.left, box.top, box.bottom))
                    }
                }
                out
            } finally {
                recognizer.close()
            }
        }

    // ---------- Lógica pura (testável sem ML Kit) ----------

    internal fun buildRows(lines: List<OcrLine>, students: List<Student>): List<ScannedGradeRow> {
        val rowTexts = clusterRows(lines)

        data class Candidate(val studentIdx: Int, val rowIdx: Int, val score: Double)

        val candidates = mutableListOf<Candidate>()
        students.forEachIndexed { si, st ->
            rowTexts.forEachIndexed { ri, rowText ->
                val score = matchScore(st.fullName, rowText)
                if (score > 0.0) candidates.add(Candidate(si, ri, score))
            }
        }

        val studentToRow = mutableMapOf<Int, Int>()
        val usedRows = mutableSetOf<Int>()
        for (c in candidates.sortedByDescending { it.score }) {
            if (c.studentIdx in studentToRow || c.rowIdx in usedRows) continue
            studentToRow[c.studentIdx] = c.rowIdx
            usedRows.add(c.rowIdx)
        }

        return students.mapIndexed { si, st ->
            val rowIdx = studentToRow[si]
            if (rowIdx == null) {
                ScannedGradeRow(
                    studentName = st.fullName,
                    studentNumber = st.studentNumber,
                    matchedStudentId = st.id,
                    notes = NOT_FOUND_NOTE
                )
            } else {
                val grades = extractGrades(rowTexts[rowIdx], st.studentNumber)
                ScannedGradeRow(
                    studentName = st.fullName,
                    studentNumber = st.studentNumber,
                    matchedStudentId = st.id,
                    acs1 = grades.getOrNull(0),
                    acs2 = grades.getOrNull(1),
                    at = grades.getOrNull(2),
                    exam = grades.getOrNull(3),
                    notes = FOUND_NOTE
                )
            }
        }
    }

    /** Agrupa linhas de texto que estão à mesma altura na imagem (uma linha da tabela) e junta-as da esquerda para a direita. */
    internal fun clusterRows(lines: List<OcrLine>): List<String> {
        if (lines.isEmpty()) return emptyList()
        val heights = lines.map { (it.bottom - it.top).coerceAtLeast(1) }.sorted()
        val tolerance = (heights[heights.size / 2] / 2).coerceAtLeast(4)
        val sorted = lines.sortedBy { (it.top + it.bottom) / 2 }

        val rows = mutableListOf<MutableList<OcrLine>>()
        var currentCenter = 0
        for (line in sorted) {
            val center = (line.top + line.bottom) / 2
            if (rows.isEmpty() || kotlin.math.abs(center - currentCenter) > tolerance) {
                rows.add(mutableListOf(line))
                currentCenter = center
            } else {
                rows.last().add(line)
            }
        }
        return rows.map { row -> row.sortedBy { it.left }.joinToString(" ") { it.text } }
    }

    /** Proporção das palavras do nome do aluno encontradas na linha; 0.0 se a correspondência for fraca. */
    internal fun matchScore(fullName: String, rowText: String): Double {
        val nameTokens = normalize(fullName).split(" ").filter { it.length >= 3 }
        if (nameTokens.isEmpty()) return 0.0
        val rowTokens = normalize(rowText).split(" ").filter { it.isNotEmpty() }
        val hits = nameTokens.count { n -> rowTokens.any { r -> tokenMatches(n, r) } }
        val score = hits.toDouble() / nameTokens.size
        val minHits = minOf(2, nameTokens.size)
        return if (hits >= minHits && score >= 0.6) score else 0.0
    }

    /** Extrai valores entre 0 e 20 que aparecem depois do nome (ignora o número do aluno e a ordem). */
    internal fun extractGrades(rowText: String, studentNumber: String): List<Double> {
        var t = rowText
        if (studentNumber.isNotBlank()) t = t.replace(studentNumber, " ", ignoreCase = true)
        t = t.replace(Regex("[A-Za-z]+-\\d+(-\\d+)*"), " ")
        val firstLetter = t.indexOfFirst { it.isLetter() }
        if (firstLetter > 0) t = t.substring(firstLetter)
        return Regex("(?<![\\d.,])\\d{1,2}(?:[.,]\\d{1,2})?(?!\\d)")
            .findAll(t)
            .mapNotNull { it.value.replace(',', '.').toDoubleOrNull() }
            .filter { it in 0.0..20.0 }
            .toList()
    }

    private fun normalize(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .lowercase(Locale.ROOT)
            .replace(Regex("[^a-z ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun tokenMatches(a: String, b: String): Boolean {
        if (a == b) return true
        if (a.length < 5 || b.length < 5) return false
        return levenshtein(a, b) <= 1
    }

    private fun levenshtein(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + cost)
                prev = tmp
            }
        }
        return dp[b.length]
    }
}
