package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Classroom
import com.example.data.model.GradeRecord
import com.example.data.model.PautaLock
import com.example.data.model.Student
import com.example.data.model.Subject
import com.example.data.model.UserRole
import com.example.ui.components.ExportActionBar
import com.example.ui.theme.AcademicBlue
import com.example.ui.theme.AcademicEmerald
import com.example.ui.theme.AcademicGreen
import com.example.ui.theme.AcademicRed
import com.example.ui.theme.CuanineNavy
import com.example.ui.theme.GoldAccent
import com.example.util.DocxExporter
import com.example.util.PdfExporter
import com.example.util.PrintHelper
import com.example.util.SneCalculator
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherScreen(
    students: List<Student>,
    classrooms: List<Classroom>,
    subjects: List<Subject>,
    grades: List<GradeRecord>,
    pautaLocks: List<PautaLock>,
    currentRole: UserRole,
    onSaveGrade: (studentId: Long, subjectId: Long, term: Int, acs1: Double?, acs2: Double?, at: Double?, exam: Double?, qualitative: String?) -> Unit,
    onStudentClick: (Student) -> Unit,
    onOcrScanTrigger: (Uri, gradeClass: Int, section: String) -> Unit,
    onLockPauta: (gradeClass: Int, section: String, subjectId: Long, term: Int) -> Unit,
    onUnlockPauta: (gradeClass: Int, section: String, subjectId: Long, term: Int) -> Unit,
    onSaveAttendance: (attendanceMap: Map<Long, String>, subjectId: Long, term: Int) -> Unit = { _, _, _ -> },
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Pauta de Avaliação, 1: Folha de Assiduidade (Presenças)

    var selectedClassroom by remember(classrooms) {
        mutableStateOf(classrooms.firstOrNull() ?: Classroom(cycle = 3, grade = 10, section = "A", roomName = "Sala 1", classTeacher = "Prof. Mondlane"))
    }
    var selectedSubject by remember(subjects) {
        mutableStateOf(subjects.firstOrNull() ?: Subject(name = "Língua Portuguesa", code = "PORT"))
    }
    var selectedTerm by remember { mutableIntStateOf(1) }

    var classExpanded by remember { mutableStateOf(false) }
    var subjectExpanded by remember { mutableStateOf(false) }

    // Estado da presença em memória para a chamada do dia
    val attendanceStates = remember { mutableStateMapOf<Long, String>() }

    val filteredStudents = remember(students, selectedClassroom) {
        students.filter { it.gradeClass == selectedClassroom.grade && it.section == selectedClassroom.section && it.enrollmentStatus == "ACTIVO" }
    }

    val gradesMap = remember(grades, selectedSubject, selectedTerm) {
        grades.filter { it.subjectId == selectedSubject.id && it.term == selectedTerm }
            .associateBy { it.studentId }
    }

    // Verifica se esta pauta específica está trancada após o Conselho de Notas
    val isLocked = remember(pautaLocks, selectedClassroom, selectedSubject, selectedTerm) {
        pautaLocks.any {
            it.gradeClass == selectedClassroom.grade &&
            it.section == selectedClassroom.section &&
            it.subjectId == selectedSubject.id &&
            it.term == selectedTerm &&
            it.isLocked
        }
    }

    val ocrPhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            if (isLocked && currentRole == UserRole.PROFESSOR) {
                Toast.makeText(context, "Pauta trancada pelo Conselho de Notas! Apenas o Técnico ICT pode editar.", Toast.LENGTH_LONG).show()
            } else {
                onOcrScanTrigger(uri, selectedClassroom.grade, selectedClassroom.section)
            }
        }
    }

    fun exportPautaPdf() {
        if (filteredStudents.isEmpty()) {
            Toast.makeText(context, "Não há alunos nesta turma para exportar.", Toast.LENGTH_SHORT).show()
            return
        }
        val file = PdfExporter.exportPautaPdf(
            context = context,
            classroom = selectedClassroom,
            subject = selectedSubject,
            term = selectedTerm,
            students = filteredStudents,
            gradesMap = gradesMap
        )
        PdfExporter.shareFile(context, file)
    }

    fun exportPautaDocx() {
        if (filteredStudents.isEmpty()) {
            Toast.makeText(context, "Não há alunos nesta turma para exportar.", Toast.LENGTH_SHORT).show()
            return
        }
        val file = DocxExporter.exportPautaDocx(
            context = context,
            classroom = selectedClassroom,
            subject = selectedSubject,
            term = selectedTerm,
            students = filteredStudents,
            gradesMap = gradesMap
        )
        DocxExporter.shareDocx(context, file)
    }

    fun printDirectMinedh() {
        if (filteredStudents.isEmpty()) {
            Toast.makeText(context, "Não há alunos para imprimir.", Toast.LENGTH_SHORT).show()
            return
        }
        val file = PdfExporter.exportPautaPdf(
            context = context,
            classroom = selectedClassroom,
            subject = selectedSubject,
            term = selectedTerm,
            students = filteredStudents,
            gradesMap = gradesMap
        )
        PrintHelper.printPdfDocument(context, file, "Pauta_${selectedClassroom.grade}_${selectedSubject.code}")
    }

    Column(modifier = modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Pauta de Notas (SNE)", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Folha de Assiduidade Diária", fontWeight = FontWeight.Bold) }
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Seletores de Turma e Disciplina
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ExposedDropdownMenuBox(
                                expanded = classExpanded,
                                onExpandedChange = { classExpanded = it },
                                modifier = Modifier.weight(1f)
                            ) {
                                OutlinedTextField(
                                    value = "${selectedClassroom.grade}.ª '${selectedClassroom.section}'",
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Turma") },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = classExpanded) },
                                    modifier = Modifier.menuAnchor()
                                )
                                ExposedDropdownMenu(
                                    expanded = classExpanded,
                                    onDismissRequest = { classExpanded = false }
                                ) {
                                    classrooms.forEach { cr ->
                                        DropdownMenuItem(
                                            text = { Text("${cr.grade}.ª Classe '${cr.section}' (${cr.shift})") },
                                            onClick = {
                                                selectedClassroom = cr
                                                classExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            ExposedDropdownMenuBox(
                                expanded = subjectExpanded,
                                onExpandedChange = { subjectExpanded = it },
                                modifier = Modifier.weight(1.3f)
                            ) {
                                OutlinedTextField(
                                    value = selectedSubject.name,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Disciplina") },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = subjectExpanded) },
                                    modifier = Modifier.menuAnchor()
                                )
                                ExposedDropdownMenu(
                                    expanded = subjectExpanded,
                                    onDismissRequest = { subjectExpanded = false }
                                ) {
                                    subjects.forEach { sub ->
                                        DropdownMenuItem(
                                            text = { Text(sub.name) },
                                            onClick = {
                                                selectedSubject = sub
                                                subjectExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(1, 2, 3).forEach { term ->
                                FilterChip(
                                    selected = selectedTerm == term,
                                    onClick = { selectedTerm = term },
                                    label = { Text("$term.º Trimestre", fontSize = 12.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            // ================= BANNER DE GOVERNAÇÃO E TRAVA PÓS-CONSELHO =================
            item {
                if (isLocked) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AcademicRed.copy(alpha = 0.12f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = AcademicRed,
                                    modifier = Modifier.size(24.dp)
                                )
                                Column {
                                    Text(
                                        text = "PAUTA FECHADA PELO CONSELHO DE NOTAS",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = AcademicRed
                                    )
                                    Text(
                                        text = "Modo 'Apenas Leitura'. Edições reservadas à Soberania do Técnico ICT.",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            if (currentRole == UserRole.TECNICO_ICT) {
                                Button(
                                    onClick = {
                                        onUnlockPauta(selectedClassroom.grade, selectedClassroom.section, selectedSubject.id, selectedTerm)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)
                                ) {
                                    Icon(imageVector = Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Desbloquear (ICT)", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                } else {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AcademicGreen.copy(alpha = 0.1f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(imageVector = Icons.Default.LockOpen, contentDescription = null, tint = AcademicGreen, modifier = Modifier.size(18.dp))
                                Text(
                                    text = "Pauta Aberta para Lançamento",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = AcademicGreen
                                )
                            }

                            if (currentRole == UserRole.DIRECAO || currentRole == UserRole.TECNICO_ICT || currentRole == UserRole.PROFESSOR) {
                                OutlinedButton(
                                    onClick = {
                                        onLockPauta(selectedClassroom.grade, selectedClassroom.section, selectedSubject.id, selectedTerm)
                                    }
                                ) {
                                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Trancar Pós-Conselho", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            if (selectedTab == 0) {
                // ================= MODO 1: PAUTA DE AVALIAÇÃO =================
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Scanner OCR
                        Button(
                            onClick = {
                                ocrPhotoLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                            shape = RoundedCornerShape(10.dp),
                            enabled = !isLocked || currentRole == UserRole.TECNICO_ICT,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Scanner OCR", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        // Impressão Direta MINEDH
                        Button(
                            onClick = { printDirectMinedh() },
                            colors = ButtonDefaults.buttonColors(containerColor = AcademicEmerald),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Imprimir MINEDH", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Botões de Exportação Dual (Word .docx e PDF .pdf)
                item {
                    ExportActionBar(
                        onExportPdf = { exportPautaPdf() },
                        onExportDocx = { exportPautaDocx() },
                        pdfLabel = "Pauta em PDF (.pdf)",
                        docxLabel = "Pauta em Word (.docx)"
                    )
                }

                // Cabeçalho da Lista
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Estudantes (${filteredStudents.size}) - ${selectedClassroom.grade}.ª '${selectedClassroom.section}'",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = SneCalculator.getCycleTitle(selectedClassroom.cycle),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                items(filteredStudents) { student ->
                    val grade = gradesMap[student.id]
                    val isCycle1 = selectedClassroom.cycle == 1

                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (!isLocked || currentRole == UserRole.TECNICO_ICT) {
                                    onStudentClick(student)
                                } else {
                                    Toast.makeText(context, "Pauta trancada pelo Conselho de Notas (Apenas Leitura).", Toast.LENGTH_SHORT).show()
                                }
                            }
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.primaryContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = student.fullName.take(1),
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Column {
                                        Text(
                                            text = student.fullName,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                        Text(
                                            text = "${student.studentNumber} • Ver Ficha",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }

                                val avg = grade?.termAverage
                                if (isCycle1) {
                                    val mention = grade?.qualitative ?: SneCalculator.getQualitativeMention(avg)
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(AcademicEmerald.copy(alpha = 0.15f))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = mention,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = AcademicEmerald
                                        )
                                    }
                                } else {
                                    val isPass = avg != null && avg >= 10.0
                                    val badgeColor = if (avg == null) Color.Gray else if (isPass) AcademicGreen else AcademicRed
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(badgeColor.copy(alpha = 0.15f))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = avg?.let { "${String.format(Locale.US, "%.1f", it)} Val" } ?: "Pendente",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = badgeColor
                                        )
                                    }
                                }
                            }

                            if (!isCycle1) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 5.dp),
                                    horizontalArrangement = Arrangement.SpaceAround
                                ) {
                                    Text("ACS1: ${grade?.acs1?.let { String.format(Locale.US, "%.1f", it) } ?: "-"}", fontSize = 11.sp)
                                    Text("ACS2: ${grade?.acs2?.let { String.format(Locale.US, "%.1f", it) } ?: "-"}", fontSize = 11.sp)
                                    Text("AT: ${grade?.at?.let { String.format(Locale.US, "%.1f", it) } ?: "-"}", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            } else {
                // ================= MODO 2: FOLHA DE ASSIDUIDADE DIÁRIA =================
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AcademicEmerald),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(imageVector = Icons.Default.EventAvailable, contentDescription = null, tint = Color.White)
                                Text(
                                    text = "Folha de Presenças Diárias (MINEDH)",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Text(
                                text = "P: Presente • FJ: Falta Justificada • FI: Falta Injustificada",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }
                    }
                }

                // Ações Rápidas de Assiduidade
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                filteredStudents.forEach { attendanceStates[it.id] = "P" }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Marcar Todos 'P'", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = {
                                attendanceStates.clear()
                            },
                            modifier = Modifier.weight(0.7f)
                        ) {
                            Text("Limpar", fontSize = 11.sp)
                        }
                    }
                }

                items(filteredStudents) { st ->
                    val currentStatus = attendanceStates[st.id] ?: "P"

                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(st.fullName, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(st.studentNumber, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            // Botões Rápidos de Assiduidade: P, FJ, FI
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                FilterChip(
                                    selected = currentStatus == "P",
                                    onClick = { attendanceStates[st.id] = "P" },
                                    label = { Text("P", fontWeight = FontWeight.Bold) }
                                )
                                FilterChip(
                                    selected = currentStatus == "FJ",
                                    onClick = { attendanceStates[st.id] = "FJ" },
                                    label = { Text("FJ", fontWeight = FontWeight.Bold) }
                                )
                                FilterChip(
                                    selected = currentStatus == "FI",
                                    onClick = { attendanceStates[st.id] = "FI" },
                                    label = { Text("FI", fontWeight = FontWeight.Bold) }
                                )
                            }
                        }
                    }
                }

                item {
                    Button(
                        onClick = {
                            val completeAttendance = filteredStudents.associate { it.id to (attendanceStates[it.id] ?: "P") }
                            onSaveAttendance(completeAttendance, selectedSubject.id, selectedTerm)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CuanineNavy),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.FactCheck, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Confirmar Presenças do Dia", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
