package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// EB Cuanine Identity Colors - Inspired by Mozambican Academic & Regional Palette
val CuanineNavy = Color(0xFF0A2540)
val CuanineNavyDark = Color(0xFF06182B)
val CuanineNavyLight = Color(0xFF1E3A5F)

val GoldAccent = Color(0xFFD97706)
val GoldAccentLight = Color(0xFFFBBF24)
val GoldAccentDark = Color(0xFFB45309)

val AcademicEmerald = Color(0xFF0D9488)
val AcademicEmeraldLight = Color(0xFF14B8A6)
val AcademicGreen = Color(0xFF16A34A)
val AcademicRed = Color(0xFFDC2626)
val AcademicBlue = Color(0xFF2563EB)

// Neutrals
val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate300 = Color(0xFFCBD5E1)
val Slate600 = Color(0xFF475569)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)

// Dark Theme Variants
val DarkBackground = Color(0xFF0B1320)
val DarkSurface = Color(0xFF132035)
val DarkSurfaceVariant = Color(0xFF1E2E48)
val DarkTextPrimary = Color(0xFFF1F5F9)
val DarkTextSecondary = Color(0xFF94A3B8)
