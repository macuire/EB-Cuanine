package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = GoldAccentLight,
  onPrimary = CuanineNavyDark,
  primaryContainer = CuanineNavyLight,
  onPrimaryContainer = Color.White,
  secondary = AcademicEmeraldLight,
  onSecondary = Color.Black,
  secondaryContainer = Color(0xFF042F2C),
  onSecondaryContainer = Color(0xFFCCFBF1),
  tertiary = GoldAccent,
  onTertiary = Color.Black,
  background = DarkBackground,
  onBackground = DarkTextPrimary,
  surface = DarkSurface,
  onSurface = DarkTextPrimary,
  surfaceVariant = DarkSurfaceVariant,
  onSurfaceVariant = DarkTextSecondary,
  error = Color(0xFFF87171),
  onError = Color.Black
)

private val LightColorScheme = lightColorScheme(
  primary = CuanineNavy,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFE0EBF7),
  onPrimaryContainer = CuanineNavy,
  secondary = GoldAccent,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFFEF3C7),
  onSecondaryContainer = GoldAccentDark,
  tertiary = AcademicEmerald,
  onTertiary = Color.White,
  background = Slate50,
  onBackground = Slate900,
  surface = Color.White,
  onSurface = Slate900,
  surfaceVariant = Slate100,
  onSurfaceVariant = Slate700,
  error = AcademicRed,
  onError = Color.White
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Keep distinct EB Cuanine school brand colors
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
