package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Estados da Matrícula Escolar na EB Cuanine.
 */
enum class EnrollmentStatus(val label: String, val badgeColorHex: Long) {
    ACTIVO("Activo", 0xFF16A34A),
    DESISTIDO("Desistido", 0xFFDC2626),
    TRANSFERIDO("Transferido", 0xFFD97706)
}

/**
 * Entidade Aluno da Escola Básica de Cuanine.
 * Totalmente autónomo e offline (Room SQLite).
 */
@Entity(
    tableName = "students",
    indices = [
        Index(value = ["studentNumber"], unique = true),
        Index(value = ["gradeClass", "section"]),
        Index(value = ["cycle"]),
        Index(value = ["enrollmentStatus"])
    ]
)
data class Student(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val studentNumber: String, // ex: "EBC-2026-001"
    val fullName: String,
    val birthDate: String, // AAAA-MM-DD
    val gender: String, // "M" ou "F"
    val guardianName: String,
    val guardianPhone: String,
    val address: String = "Cuanine, Manhiça",
    val cycle: Int, // 1, 2 ou 3
    val gradeClass: Int, // 1 à 10
    val section: String = "A", // A, B, C, D
    val schoolYear: Int = 2026,
    val docType: String = "BI", // "BI", "Cédula Pessoal", "Certidão de Nascimento"
    val docNumber: String = "",
    val photoUri: String? = null,
    val docPhotoUri: String? = null,
    val accessPin: String = "1234", // PIN de consulta individual do aluno/encarregado
    val enrollmentStatus: String = "ACTIVO", // "ACTIVO", "DESISTIDO", "TRANSFERIDO"
    val transferDestination: String? = null, // ex: "EPC Manhiça-Sede", "EPC Maragra"
    val dropReason: String? = null, // ex: "Mudança de residência", "Actividade agrícola familiar"
    val isEnrolled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Turmas e Salas da Escola Básica de Cuanine.
 */
@Entity(
    tableName = "classrooms",
    indices = [Index(value = ["grade", "section", "schoolYear"], unique = true)]
)
data class Classroom(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val cycle: Int, // 1: 1ª-2ª; 2: 3ª-5ª; 3: 6ª-10ª
    val grade: Int, // 1 a 10
    val section: String, // "A", "B", "C"
    val roomName: String, // ex: "Sala 02 - Bloco Principal"
    val classTeacher: String, // Professor da Turma / Diretor de Turma
    val shift: String = "Manhã", // "Manhã", "Tarde"
    val schoolYear: Int = 2026
)

/**
 * Disciplinas do Currículo Nacional do SNE.
 */
@Entity(tableName = "subjects")
data class Subject(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val code: String, // PORT, MAT, CN, HIST, GEO, etc.
    val applicableCycles: String = "1,2,3" // CSV com ciclos onde é lecionada
)

/**
 * Pauta e Registro de Avaliações (ACS, AT, Exame, Médias)
 */
@Entity(
    tableName = "grades",
    indices = [
        Index(value = ["studentId", "subjectId", "term", "schoolYear"], unique = true),
        Index(value = ["studentId"]),
        Index(value = ["subjectId"])
    ],
    foreignKeys = [
        ForeignKey(
            entity = Student::class,
            parentColumns = ["id"],
            childColumns = ["studentId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = Subject::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class GradeRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val studentId: Long,
    val subjectId: Long,
    val term: Int, // 1.º, 2.º ou 3.º Trimestre
    val schoolYear: Int = 2026,
    // Avaliações Contínuas e Sistemáticas (ACS)
    val acs1: Double? = null,
    val acs2: Double? = null,
    val acs3: Double? = null,
    // Avaliação Trimestral (AT)
    val at: Double? = null,
    // Exame ou Prova de Ciclo
    val exam: Double? = null,
    // Avaliação Qualitativa Descritiva (1.º Ciclo SNE: "Muito Bom", "Bom", "Suficiente", "Não Suficiente")
    val qualitative: String? = null,
    // Média Trimestral calculada pelo SNE
    val termAverage: Double? = null,
    // Faltas
    val absences: Int = 0,
    val teacherComment: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Trava e Governação de Pautas Pós-Conselho de Notas
 */
@Entity(
    tableName = "pauta_locks",
    primaryKeys = ["gradeClass", "section", "subjectId", "term"]
)
data class PautaLock(
    val gradeClass: Int,
    val section: String,
    val subjectId: Long,
    val term: Int,
    val isLocked: Boolean = false,
    val lockedBy: String = "Conselho de Notas",
    val lockedAt: Long = System.currentTimeMillis(),
    val unlockReason: String? = null
)

/**
 * Notícias e Avisos Institucionais (Mural Estilo Google Notícias)
 */
@Entity(tableName = "school_notices")
data class SchoolNotice(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val summary: String,
    val body: String,
    val category: String, // "Conselho de Notas", "Calendário", "Saúde Escolar", "Comunidade"
    val publishDate: String,
    val priority: String = "NORMAL", // "DESTAQUE", "NORMAL", "URGENTE"
    val author: String = "Direcção da Escola"
)

/**
 * Folha de Assiduidade e Presenças Diárias
 */
@Entity(
    tableName = "attendance_records",
    indices = [Index(value = ["studentId", "subjectId", "date"], unique = true)]
)
data class AttendanceRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val studentId: Long,
    val subjectId: Long,
    val date: String, // AAAA-MM-DD
    val status: String = "P", // "P" (Presente), "FJ" (Falta Justificada), "FI" (Falta Injustificada)
    val term: Int = 1
)

/**
 * Configuração Dinâmica de Fórmulas e Pesos do SNE (Editável pelo Técnico ICT / Direção)
 */
@Entity(tableName = "formula_configs")
data class FormulaConfig(
    @PrimaryKey
    val cycle: Int, // 1, 2 ou 3
    val cycleName: String,
    val acs1Weight: Double = 1.0,
    val acs2Weight: Double = 1.0,
    val atWeight: Double = 2.0,
    val examWeight: Double = 1.0,
    val minPassGrade: Double = 10.0,
    val formulaDescription: String = "MT = (ACS1 + ACS2 + 2*AT) / 4",
    val isQualitative: Boolean = false
)

/**
 * Perfil de Acesso no Sistema
 */
enum class UserRole(val label: String, val badgeColorHex: Long) {
    DIRECAO("Direção", 0xFF0A2540),
    PROFESSOR("Professor", 0xFF0D9488),
    ALUNO_ENCARREGADO("Aluno / Encarregado", 0xFFD97706),
    CONSELHO_ESCOLA("Conselho de Escola", 0xFF2563EB),
    TECNICO_ICT("Técnico ICT", 0xFF7C3AED)
}

/**
 * Biografia e Apresentação do Professor
 */
data class TeacherBio(
    val name: String,
    val title: String,
    val role: String,
    val room: String,
    val experienceYears: Int,
    val mainSubjects: String,
    val bio: String,
    val welcomeMessage: String,
    val phone: String = "+258 84 000 0000"
)

/**
 * Entidade Docente da Escola Básica de Cuanine (Fase 2 - Base de dados).
 */
@Entity(
    tableName = "teachers",
    indices = [
        Index(value = ["teacherCode"], unique = true),
        Index(value = ["fullName"])
    ]
)
data class Teacher(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val teacherCode: String, // ex: "DOC-EBC-01"
    val fullName: String,
    val gender: String = "M",
    val phone: String = "+258 84 000 0000",
    val email: String? = null,
    val idDocument: String = "",
    val contractType: String = "Efectivo", // "Efectivo", "Contratado", "Estagiário"
    val category: String = "Docente N1", // "Docente N1", "Docente N2", "Docente N3"
    val hireDate: String = "2020-02-01",
    val assignedClassroom: String = "Sala 1 - Bloco A",
    val mainSubjects: String = "Língua Portuguesa, Matemática",
    val status: String = "ACTIVO", // "ACTIVO", "LICENÇA", "TRANSFERIDO"
    val photoUri: String? = null,
    val bio: String = "Professor dedicado da comunidade de Cuanine, Manhiça."
)

